Directions:

0. Do not use this software.
1. Please consult LICENSE.txt for details concerning step 0.
2. If you have build errors, make sure your libnds is up-to-date.